<?php
include("connect.php");
$username="Client";
$password=password_hash("Client@12",true);
try{
$in="INSERT INTO users (username,password) VALUES('$username','$password')";
$save=mysqli_query($conn,$in);
if($save){
    echo"user registred successfully";
}else{
    echo "error ".mysqli_error($conn);
}
}catch(PDOException $e){
    echo "error ".$e->getMessage();
}
?>