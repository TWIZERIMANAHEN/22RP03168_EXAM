<?php
$servername="localhost";
$username="root";
$password="";
$dbname="class";
$conn=mysqli_connect("localhost","root","","nextech_portal_22RP03168");
?>